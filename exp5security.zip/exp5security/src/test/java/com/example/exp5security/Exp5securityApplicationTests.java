package com.example.exp5security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exp5securityApplicationTests {

	@Test
	void contextLoads() {
	}

}
